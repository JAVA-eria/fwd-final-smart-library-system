/**
 * Book Routes - REST API Endpoints
 * 
 * This file defines the API routes for book management:
 * - GET /api/books - Retrieve all books
 * - POST /api/books - Add a new book
 * - DELETE /api/books/:id - Remove a book by ID
 */

const express = require('express');
const router = express.Router();
const Book = require('../models/Book');

// ============================================
// GET /api/books - Retrieve all books
// ============================================
router.get('/', async (req, res) => {
  try {
    // Fetch all books from database, sorted by newest first
    const books = await Book.find().sort({ createdAt: -1 });
    
    // Return success response with books array
    res.status(200).json({
      success: true,
      count: books.length,
      data: books
    });
  } catch (error) {
    // Handle database errors
    console.error('Error fetching books:', error.message);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch books from database',
      error: error.message
    });
  }
});

// ============================================
// POST /api/books - Add a new book
// ============================================
router.post('/', async (req, res) => {
  try {
    // Extract book data from request body
    const { title, author, isbn, year } = req.body;
    
    // Validate that all required fields are provided
    if (!title || !author || !isbn || !year) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields: title, author, isbn, year'
      });
    }
    
    // Create new book document in database
    const newBook = await Book.create({
      title,
      author,
      isbn,
      year: parseInt(year) // Ensure year is stored as number
    });
    
    // Return success response with created book
    res.status(201).json({
      success: true,
      message: 'Book added successfully',
      data: newBook
    });
  } catch (error) {
    // Handle validation or database errors
    console.error('Error adding book:', error.message);
    res.status(500).json({
      success: false,
      message: 'Failed to add book to database',
      error: error.message
    });
  }
});

// ============================================
// DELETE /api/books/:id - Remove a book by ID
// ============================================
router.delete('/:id', async (req, res) => {
  try {
    // Extract book ID from URL parameters
    const { id } = req.params;
    
    // Find and delete the book by ID
    const deletedBook = await Book.findByIdAndDelete(id);
    
    // Check if book was found and deleted
    if (!deletedBook) {
      return res.status(404).json({
        success: false,
        message: 'Book not found with the provided ID'
      });
    }
    
    // Return success response
    res.status(200).json({
      success: true,
      message: 'Book deleted successfully',
      data: deletedBook
    });
  } catch (error) {
    // Handle invalid ID format or database errors
    console.error('Error deleting book:', error.message);
    res.status(500).json({
      success: false,
      message: 'Failed to delete book from database',
      error: error.message
    });
  }
});

module.exports = router;

