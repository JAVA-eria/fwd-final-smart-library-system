# Smart Library System

A MERN stack single page application that allows librarians to manage books.

## Features
Add books
View all books
Delete books

## Setup Instructions

### Backend
cd server
npm install
npm start

### Frontend
cd client
npm install
npm start