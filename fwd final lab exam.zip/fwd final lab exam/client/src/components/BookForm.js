import React, { useState } from "react";
import axios from "axios";

function BookForm() {
  const [formData, setFormData] = useState({
    title: "",
    author: "",
    isbn: "",
    year: ""
  });

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/books", formData);
      setFormData({ title: "", author: "", isbn: "", year: "" });
      window.location.reload();
    } catch {
      alert("Failed to add book");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="title" placeholder="Book Title" value={formData.title} onChange={handleChange} />
      <input name="author" placeholder="Author Name" value={formData.author} onChange={handleChange} />
      <input name="isbn" placeholder="ISBN Number" value={formData.isbn} onChange={handleChange} />
      <input name="year" placeholder="Publication Year" value={formData.year} onChange={handleChange} />
      <button type="submit">Add Book</button>
    </form>
  );
}

export default BookForm;