import React, { useEffect, useState } from "react";
import axios from "axios";

function BookList() {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/books");
      setBooks(res.data);
    } catch (error) {
      alert("Failed to fetch books");
    }
  };

  const deleteBook = async id => {
    try {
      await axios.delete(`http://localhost:5000/api/books/${id}`);
      fetchBooks();
    } catch (error) {
      alert("Failed to delete book");
    }
  };

  return (
    <div className="book-list">
      {books.map(book => (
        <div className="book-card" key={book._id}>
          <h3>{book.title}</h3>
          <p>{book.author}</p>
          <p>{book.isbn}</p>
          <p>{book.year}</p>
          <button onClick={() => deleteBook(book._id)}>Delete</button>
        </div>
      ))}
    </div>
  );
}

export default BookList;