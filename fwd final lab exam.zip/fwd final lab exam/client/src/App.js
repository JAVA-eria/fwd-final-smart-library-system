import React from "react";
import BookForm from "./components/BookForm";
import BookList from "./components/BookList";
import "./App.css";

function App() {
  return (
    <div className="container">
      <h1>Smart Library System</h1>
      <BookForm />
      <BookList />
    </div>
  );
}

export default App;