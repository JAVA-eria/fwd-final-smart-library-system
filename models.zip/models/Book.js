/**
 * Book Model - Mongoose Schema Definition
 * 
 * This file defines the schema for Book documents in MongoDB.
 * Each book has: title, author, isbn, and year fields.
 */

const mongoose = require('mongoose');

// Define the Book schema with validation rules
const bookSchema = new mongoose.Schema({
  // Book title - required field
  title: {
    type: String,
    required: [true, 'Book title is required'],
    trim: true // Removes whitespace from both ends
  },
  
  // Author name - required field
  author: {
    type: String,
    required: [true, 'Author name is required'],
    trim: true
  },
  
  // ISBN number - required field with unique constraint
  isbn: {
    type: String,
    required: [true, 'ISBN number is required'],
    trim: true
  },
  
  // Publication year - required field
  year: {
    type: Number,
    required: [true, 'Publication year is required'],
    min: [1000, 'Year must be a valid 4-digit year'],
    max: [new Date().getFullYear(), 'Year cannot be in the future']
  }
}, {
  // Automatically add createdAt and updatedAt timestamps
  timestamps: true
});

// Create and export the Book model
const Book = mongoose.model('Book', bookSchema);

module.exports = Book;

